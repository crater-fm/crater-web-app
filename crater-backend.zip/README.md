# Crater

Crater is a web app that provides music recommendations with a human touch. We believe that humans make the best mixtapes, so we've pulled the most inventive DJ sets from the web and used the data to generate recommended playlists for our users.

Try out the MVP at https://crater-web-server.herokuapp.com/

# License
[MIT](https://choosealicense.com/licenses/mit/)

Architecture diagrams:
![Architecture diagrams created with Excalidraw](https://github.com/drex04/crater-web-app/blob/master/notebook/arch-diagrams/Target%20Arch%2027%20Oct%202021.png)